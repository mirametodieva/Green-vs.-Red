package game;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x = 3;
        int y = 3;
        int x1 = 0;
        int y1 = 1;
        int[][] grid = new int[x][y];

        int count = 0;

        for (int i = 0; i < y; i++) {
            for (int j = 0; j < x; j++) {
                int var = in.nextInt();
                grid[j][i] = var;

            }
        }

        for (int i = 0; i < y; i++) {
            for (int j = 0; j < x; j++) {
                if (i == 0 && j == 0) { //left top corner
                    if (grid[j][i] == 0 && grid[j][i + 1] + grid[j + 1][i + 1] + grid[j + 1][i + 1] == 3) {
                        grid[j][i] = 1;
                    } else if (grid[j][i] == 1 && grid[j + 1][i] + grid[j + 1][i + 1] + grid[j + 1][i + 1] == 0) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j + 1][i] + grid[j + 1][i + 1] + grid[j + 1][i + 1] == 1) {
                        grid[j][i] = 0;
                    }
                }  if (i == 0 && j == x - 1) { //right top corner
                    if (grid[j][i] == 0 && grid[j - 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] == 3) {
                        grid[j][i] = 1;
                    } else if (grid[j][i] == 1 && grid[j - 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] == 0) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j - 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] == 1) {
                        grid[j][i] = 0;
                    }
                }  if (i == y - 1 && j == 0) { // left down corner
                    if (grid[j][i] == 0 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] == 3) {
                        grid[j][i] = 1;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] == 0) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] == 1) {
                        grid[j][i] = 0;
                    }
                }  if (i == y - 1 && j == x - 1) { // right down corner
                    if (grid[j][i] == 0 && grid[j][i - 1] + grid[j - 1][i - 1] + grid[j][i - 1] == 3) {
                        grid[j][i] = 1;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j - 1][i - 1] + grid[j - 1][i] == 0) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j - 1][i - 1] + grid[j - 1][i] == 1) {
                        grid[j][i] = 0;
                    }
                }
                if (j == 0 && i != 0 && i != y - 1) { // left line
                    if (grid[j][i] == 0 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] + grid[j + 1][i + 1] + grid[j][i + 1] == 3) {
                        grid[j][i] = 1;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] + grid[j + 1][i + 1] + grid[j][i + 1] == 0) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] + grid[j + 1][i + 1] + grid[j][i + 1] == 1) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] + grid[j + 1][i + 1] + grid[j][i + 1] == 4) {
                        grid[j][i] = 0;
                    } else if (grid[j][i] == 1 && grid[j][i - 1] + grid[j + 1][i - 1] + grid[j + 1][i] + grid[j + 1][i + 1] + grid[j][i + 1] == 5) {
                        grid[j][i] = 0;
                    }
                }
            }
        }
        /*else if (grid[j][i] == 0 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 6) {
                    grid[j][i] = 1;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 0) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 1) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 4) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 5) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 7) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == 1 && (grid[j - 1][i - 1] + grid[j][i - 1] + grid[j + 1][i - 1] + grid[j - 1][i]
                        + grid[j + 1][i] + grid[j - 1][i + 1] + grid[j][i + 1] + grid[j + 1][i + 1]) == 8) {
                    grid[j][i] = 0;
                } else if (grid[j][i] == grid[x1][y1] && grid[j][i] == 1) {
                    count++;
                }*/

        for (int i = 0; i < y; i++) {
            for (int j = 0; j < x; j++) {

                System.out.println(grid[j][i]);

            }
        }
    }
}
